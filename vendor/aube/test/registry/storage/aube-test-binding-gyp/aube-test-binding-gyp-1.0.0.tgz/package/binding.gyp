{
  "targets": [
    {
      "target_name": "aube_test_binding_gyp",
      "sources": []
    }
  ]
}
