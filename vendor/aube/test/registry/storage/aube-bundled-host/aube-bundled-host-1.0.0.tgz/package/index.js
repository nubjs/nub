module.exports = require('aube-bundled-child');
