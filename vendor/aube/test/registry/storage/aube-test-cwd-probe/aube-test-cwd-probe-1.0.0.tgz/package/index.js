module.exports = "aube-test-cwd-probe";
