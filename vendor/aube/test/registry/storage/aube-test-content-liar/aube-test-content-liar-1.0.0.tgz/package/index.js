module.exports = 'lying tarball';
