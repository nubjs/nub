/* vi: set sw=4 ts=4: */
/*
 * Copyright (C) 1996 Brian Candler <B.Candler@pobox.com>
 *
 * Licensed under GPLv2 or later, see file LICENSE in this source tree.
 */
/* [date unknown. Perhaps before year 2000]
 * To achieve a small memory footprint, this version of 'ls' doesn't do any
 * file sorting, and only has the most essential command line switches
 * (i.e., the ones I couldn't live without :-) All features which involve
 * linking in substantial chunks of libc can be disabled.
 *
 * Although I don't really want to add new features to this program to
 * keep it small, I *am* interested to receive bug fixes and ways to make
 * it more portable.
 *
 * KNOWN BUGS:
 * 1. hidden files can make column width too large
 *
 * NON-OPTIMAL BEHAVIOUR:
 * 1. autowidth reads directories twice
 * 2. if you do a short directory listing without filetype characters
 *    appended, there's no need to stat each one
 * PORTABILITY:
 * 1. requires lstat (BSD) - how do you do it without?
 *
 * [2009-03]
 * ls sorts listing now, and supports almost all options.
 */
//config:config LS
//config:	bool "ls (14 kb)"
//config:	default y
//config:	help
//config:	ls is used to list the contents of directories.
//config:
//config:config FEATURE_LS_FILETYPES
//config:	bool "Enable filetyping options (-p and -F)"
//config:	default y
//config:	depends on LS
//config:
//config:config FEATURE_LS_FOLLOWLINKS
//config:	bool "Enable symlinks dereferencing (-L)"
//config:	default y
//config:	depends on LS
//config:
//config:config FEATURE_LS_RECURSIVE
//config:	bool "Enable recursion (-R)"
//config:	default y
//config:	depends on LS
//config:
//config:config FEATURE_LS_WIDTH
//config:	bool "Enable -w WIDTH and window size autodetection"
//config:	default y
//config:	depends on LS
//config:
//config:config FEATURE_LS_SORTFILES
//config:	bool "Sort the file names"
//config:	default y
//config:	depends on LS
//config:	help
//config:	Allow ls to sort file names alphabetically.
//config:
//config:config FEATURE_LS_TIMESTAMPS
//config:	bool "Show file timestamps"
//config:	default y
//config:	depends on LS
//config:	help
//config:	Allow ls to display timestamps for files.
//config:
//config:config FEATURE_LS_USERNAME
//config:	bool "Show username/groupnames"
//config:	default y
//config:	depends on LS
//config:	help
//config:	Allow ls to display username/groupname for files.
//config:
//config:config FEATURE_LS_COLOR
//config:	bool "Allow use of color to identify file types"
//config:	default y
//config:	depends on LS && LONG_OPTS
//config:	help
//config:	This enables the --color option to ls.
//config:
//config:config FEATURE_LS_COLOR_IS_DEFAULT
//config:	bool "Produce colored ls output by default"
//config:	default y
//config:	depends on FEATURE_LS_COLOR
//config:	help
//config:	Saying yes here will turn coloring on by default,
//config:	even if no "--color" option is given to the ls command.
//config:	This is not recommended, since the colors are not
//config:	configurable, and the output may not be legible on
//config:	many output screens.

//applet:IF_LS(APPLET_NOEXEC(ls, ls, BB_DIR_BIN, BB_SUID_DROP, ls))

//kbuild:lib-$(CONFIG_LS) += ls.o

//usage:#define ls_trivial_usage
//usage:	"[-1AaCxd"
//usage:	IF_PLATFORM_MINGW32("g")
//usage:	IF_FEATURE_LS_FOLLOWLINKS("LH")
//usage:	IF_FEATURE_LS_RECURSIVE("R")
//usage:	IF_FEATURE_LS_FILETYPES("Fp") "lins"
//usage:	IF_FEATURE_HUMAN_READABLE("h")
//usage:	IF_FEATURE_LS_SORTFILES("rSXv")
//usage:	IF_FEATURE_LS_TIMESTAMPS("ctu")
//usage:	IF_SELINUX("kZ") "]"
//usage:	IF_FEATURE_LS_WIDTH(" [-w WIDTH]") " [FILE]..."
//usage:#define ls_full_usage "\n\n"
//usage:       "List directory contents\n"
//usage:     "\n	-1	One column output"
//usage:     "\n	-a	Include names starting with ." IF_PLATFORM_MINGW32(" and hidden files")
//usage:     "\n	-A	Like -a, but exclude . and .."
//usage:	IF_PLATFORM_MINGW32(
//usage:     "\n	-aa,-AA	Like -a,-A but omit hidden system files"
//usage:     "\n	-C	List by columns"
//usage:	)
////usage:     "\n	-C	List by columns" - don't show, this is a default anyway
//usage:     "\n	-x	List by lines"
//usage:     "\n	-d	List directory names, not contents"
//usage:	IF_FEATURE_LS_FOLLOWLINKS(
//usage:     "\n	-L	Follow symlinks"
//usage:     "\n	-H	Follow symlinks on command line"
//usage:	)
//usage:	IF_FEATURE_LS_RECURSIVE(
//usage:     "\n	-R	Recurse"
//usage:	)
//usage:	IF_FEATURE_LS_FILETYPES(
//usage:     "\n	-p	Append / to directory names"
//usage:     "\n	-F	Append indicator (one of */=@|) to names"
//usage:	)
//usage:     "\n	-l	Long format"
//usage:	IF_PLATFORM_MINGW32(
//usage:     "\n	-g	Long format without group column"
//usage:	)
////usage:     "\n	-g	Long format without group column"
////TODO: support -G too ("suppress owner column", GNUism)
//usage:     "\n	-i	List inode numbers"
//usage:     "\n	-n	List numeric UIDs and GIDs instead of names"
//usage:     "\n	-s	List allocated blocks"
//usage:	IF_FEATURE_LS_TIMESTAMPS(
//usage:     "\n	-lc	List ctime"
//usage:     "\n	-lu	List atime"
//usage:	)
//usage:	IF_FEATURE_LS_TIMESTAMPS(IF_LONG_OPTS(
//usage:     "\n	--full-time	List full date/time"
//usage:	))
//usage:	IF_FEATURE_HUMAN_READABLE(
//usage:     "\n	-h	Human readable sizes (1K 243M 2G)"
//usage:	)
//usage:	IF_FEATURE_LS_SORTFILES(
//usage:	IF_LONG_OPTS(
//usage:     "\n	--group-directories-first"
//usage:	)
//usage:     "\n	-S	Sort by size"
//usage:     "\n	-X	Sort by extension"
//usage:     "\n	-v	Sort by version"
//usage:	)
//usage:	IF_FEATURE_LS_TIMESTAMPS(
//usage:     "\n	-t	Sort by mtime"
//usage:     "\n	-tc	Sort by ctime"
//usage:     "\n	-tu	Sort by atime"
//usage:	)
//usage:     "\n	-r	Reverse sort order"
//usage:	IF_SELINUX(
//usage:     "\n	-Z	List security context and permission"
//usage:	)
//usage:	IF_FEATURE_LS_WIDTH(
//usage:     "\n	-w N	Format N columns wide"
//usage:	)
////usage:     "\n	-Q	Double-quote names"
////usage:     "\n	-q	Replace unprintable chars with '?'"
//usage:	IF_FEATURE_LS_COLOR(
//usage:     "\n	--color[={always,never,auto}]"
//usage:	)

#include "libbb.h"
#include "common_bufsiz.h"
#include "unicode.h"


/* This is a NOEXEC applet. Be very careful! */


#if ENABLE_FTPD
/* ftpd uses ls, and without timestamps Mozilla won't understand
 * ftpd's LIST output.
 */
# undef CONFIG_FEATURE_LS_TIMESTAMPS
# undef ENABLE_FEATURE_LS_TIMESTAMPS
# undef IF_FEATURE_LS_TIMESTAMPS
# undef IF_NOT_FEATURE_LS_TIMESTAMPS
# define CONFIG_FEATURE_LS_TIMESTAMPS 1
# define ENABLE_FEATURE_LS_TIMESTAMPS 1
# define IF_FEATURE_LS_TIMESTAMPS(...) __VA_ARGS__
# define IF_NOT_FEATURE_LS_TIMESTAMPS(...)
#endif


enum {
TERMINAL_WIDTH  = 80, /* use 79 if terminal has linefold bug */

SPLIT_FILE      = 0,
SPLIT_DIR       = 1,
SPLIT_SUBDIR    = 2,
};

/* -Cadi1l  Std options, busybox always supports */
/* -gnsxA   Std options, busybox always supports */
/* -Q       GNU option, busybox always supports:  */
/*          -Q, --quote-name                     */
/*          enclose entry names in double quotes */
/* -LHRctur Std options, busybox optionally supports */
/* -Fp      Std options, busybox optionally supports */
/* -SXvhTw  GNU options, busybox optionally supports */
/* -T WIDTH Ignored (we don't use tabs on output) */
/* -Z       SELinux mandated option, busybox optionally supports */
/* -q       Std option, busybox always supports: */
/*      https://pubs.opengroup.org/onlinepubs/9699919799/utilities/ls.html: */
/*      Force each instance of non-printable filename characters and        */
/*      <tab> characters to be written as the <question-mark> ('?')         */
/*      character. Implementations may provide this option by default       */
/*      if the output is to a terminal device.                              */
/* -k       Std option, busybox always supports (by ignoring) */
/*          It means "for -s, show sizes in kbytes" */
/*          Seems to only affect "POSIXLY_CORRECT=1 ls -sk" */
/*          since otherwise -s shows kbytes anyway */
#define ls_options \
	"Cadi1lgnsxA"        /* 11 opts, total 11 */ \
	IF_FEATURE_LS_FILETYPES("Fp")    /* 2, 13 */ \
	IF_FEATURE_LS_RECURSIVE("R")     /* 1, 14 */ \
	IF_SELINUX("Z")                  /* 1, 15 */ \
	"Q"                              /* 1, 16 */ \
	IF_FEATURE_LS_TIMESTAMPS("ctu")  /* 3, 19 */ \
	IF_FEATURE_LS_SORTFILES("SXrv")  /* 4, 23 */ \
	IF_FEATURE_LS_FOLLOWLINKS("LH")  /* 2, 25 */ \
	IF_FEATURE_HUMAN_READABLE("h")   /* 1, 26 */ \
	IF_FEATURE_LS_WIDTH("T:w:")      /* 2, 28 */ \
	IF_LONG_OPTS("\xff")             /* 1, 29 */ \
	IF_LONG_OPTS("\xfe")             /* 1, 30 */ \
	IF_LONG_OPTS("\xfd::")           /* 1, 31 */ \
	"qk"                             /* 2, 33 */

#if ENABLE_LONG_OPTS
static const char ls_longopts[] ALIGN1 =
	"full-time\0" No_argument "\xff"
	"group-directories-first\0" No_argument "\xfe"
	IF_FEATURE_LS_COLOR("color\0" Optional_argument "\xfd")
;
#endif

enum {
	OPT_C = (1 << 0),
	OPT_a = (1 << 1),
	OPT_d = (1 << 2),
	OPT_i = (1 << 3),
	OPT_1 = (1 << 4),
	OPT_l = (1 << 5),
	OPT_g = (1 << 6),
	OPT_n = (1 << 7),
	OPT_s = (1 << 8),
	OPT_x = (1 << 9),
	OPT_A = (1 << 10),

	OPTBIT_F = 11,
	OPTBIT_p, /* 12 */
	OPTBIT_R = OPTBIT_F + 2 * ENABLE_FEATURE_LS_FILETYPES,
	OPTBIT_Z = OPTBIT_R + 1 * ENABLE_FEATURE_LS_RECURSIVE,
	OPTBIT_Q = OPTBIT_Z + 1 * ENABLE_SELINUX,
	OPTBIT_c, /* 16 */
	OPTBIT_t, /* 17 */
	OPTBIT_u, /* 18 */
	OPTBIT_S = OPTBIT_c + 3 * ENABLE_FEATURE_LS_TIMESTAMPS,
	OPTBIT_X, /* 20 */
	OPTBIT_r, /* 21 */
	OPTBIT_v, /* 22 */
	OPTBIT_L = OPTBIT_S + 4 * ENABLE_FEATURE_LS_SORTFILES,
	OPTBIT_H, /* 24 */
	OPTBIT_h = OPTBIT_L + 2 * ENABLE_FEATURE_LS_FOLLOWLINKS,
	OPTBIT_T = OPTBIT_h + 1 * ENABLE_FEATURE_HUMAN_READABLE,
	OPTBIT_w, /* 27 */
	OPTBIT_full_time = OPTBIT_T + 2 * ENABLE_FEATURE_LS_WIDTH,
	OPTBIT_dirs_first,
	OPTBIT_color, /* 30 */
	OPTBIT_q = OPTBIT_color + 1, /* 31 */
	OPTBIT_k = OPTBIT_q + 1, /* 32 */
	/* with all options enabled, we use all 32 bits and even one extra bit! */
	/* this works because -k is ignored, and getopt32 allows such "ignore" options past 31th bit */

	OPT_F = (1 << OPTBIT_F) * ENABLE_FEATURE_LS_FILETYPES,
	OPT_p = (1 << OPTBIT_p) * ENABLE_FEATURE_LS_FILETYPES,
	OPT_R = (1 << OPTBIT_R) * ENABLE_FEATURE_LS_RECURSIVE,
	OPT_Z = (1 << OPTBIT_Z) * ENABLE_SELINUX,
	OPT_Q = (1 << OPTBIT_Q),
	OPT_c = (1 << OPTBIT_c) * ENABLE_FEATURE_LS_TIMESTAMPS,
	OPT_t = (1 << OPTBIT_t) * ENABLE_FEATURE_LS_TIMESTAMPS,
	OPT_u = (1 << OPTBIT_u) * ENABLE_FEATURE_LS_TIMESTAMPS,
	OPT_S = (1 << OPTBIT_S) * ENABLE_FEATURE_LS_SORTFILES,
	OPT_X = (1 << OPTBIT_X) * ENABLE_FEATURE_LS_SORTFILES,
	OPT_r = (1 << OPTBIT_r) * ENABLE_FEATURE_LS_SORTFILES,
	OPT_v = (1 << OPTBIT_v) * ENABLE_FEATURE_LS_SORTFILES,
	OPT_L = (1 << OPTBIT_L) * ENABLE_FEATURE_LS_FOLLOWLINKS,
	OPT_H = (1 << OPTBIT_H) * ENABLE_FEATURE_LS_FOLLOWLINKS,
	OPT_h = (1 << OPTBIT_h) * ENABLE_FEATURE_HUMAN_READABLE,
	OPT_T = (1 << OPTBIT_T) * ENABLE_FEATURE_LS_WIDTH,
	OPT_w = (1 << OPTBIT_w) * ENABLE_FEATURE_LS_WIDTH,
	OPT_full_time  = (1 << OPTBIT_full_time ) * ENABLE_LONG_OPTS,
	OPT_dirs_first = (1 << OPTBIT_dirs_first) * ENABLE_LONG_OPTS,
	OPT_color      = (1 << OPTBIT_color     ) * ENABLE_FEATURE_LS_COLOR,
	OPT_q = (1 << OPTBIT_q),
	//-k is ignored: OPT_k = (1 << OPTBIT_k),
};

/*
 * a directory entry and its stat info
 */
struct dnode {
	const char *name;       /* usually basename, but think "ls -l dir/file" */
	const char *fullname;   /* full name (usable for stat etc) */
	struct dnode *dn_next;  /* for linked list */
	IF_SELINUX(security_context_t sid;)
	smallint fname_allocated;

	/* Used to avoid re-doing [l]stat at printout stage
	 * if we already collected needed data in scan stage:
	 */
	mode_t    dn_mode_lstat;   /* obtained with lstat, or 0 */
	mode_t    dn_mode_stat;    /* obtained with stat, or 0 */

//	struct stat dstat;
// struct stat is huge. We don't need it in full.
// At least we don't need st_dev and st_blksize,
// but there are invisible fields as well
// (such as nanosecond-resolution timespamps)
// and padding, which we also don't want to store.
// We also pre-parse dev_t dn_rdev (in glibc, it's huge).
// On 32-bit uclibc: dnode size went from 112 to 84 bytes.
//
	/* Same names as in struct stat, but with dn_ instead of st_ pfx: */
	mode_t    dn_mode; /* obtained with lstat OR stat, depending on -L etc */
	off_t     dn_size;
#if ENABLE_FEATURE_LS_TIMESTAMPS || ENABLE_FEATURE_LS_SORTFILES
	time_t    dn_time;
#endif
	ino_t     dn_ino;
	blkcnt_t  dn_blocks;
	nlink_t   dn_nlink;
	uid_t     dn_uid;
	gid_t     dn_gid;
	int       dn_rdev_maj;
	int       dn_rdev_min;
//	dev_t     dn_dev;
//	blksize_t dn_blksize;
#if ENABLE_PLATFORM_MINGW32
	DWORD     dn_attr;
#endif
};

struct globals {
#if ENABLE_FEATURE_LS_COLOR
	smallint show_color;
# define G_show_color (G.show_color)
#else
# define G_show_color 0
#endif
	smallint exit_code;
	smallint show_dirname;
	smallint tty_out;
#if ENABLE_FEATURE_LS_WIDTH
	unsigned terminal_width;
# define G_terminal_width (G.terminal_width)
#else
# define G_terminal_width TERMINAL_WIDTH
#endif
#if ENABLE_FEATURE_LS_TIMESTAMPS
	/* Do time() just once. Saves one syscall per file for "ls -l" */
	time_t current_time_t;
#endif
#if ENABLE_PLATFORM_MINGW32
	int a_count, A_count;
# define HIDSYS (FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_SYSTEM)
#endif
} FIX_ALIASING;
#define G (*(struct globals*)bb_common_bufsiz1)
#define INIT_G() do { \
	setup_common_bufsiz(); \
	/* we have to zero it out because of NOEXEC */ \
	memset(&G, 0, sizeof(G)); \
	IF_FEATURE_LS_WIDTH(G_terminal_width = ~0U;) \
	IF_FEATURE_LS_TIMESTAMPS(time(&G.current_time_t);) \
} while (0)

#define ESC "\033"

static int G_isatty(void)
{
	if (!G.tty_out) /* not known yet? */
		G.tty_out = isatty(STDOUT_FILENO) + 1;
	return (G.tty_out == 2);
}

/*** Output code ***/

/* FYI type values: 1:fifo 2:char 4:dir 6:blk 8:file 10:link 12:socket
 * (various wacky OSes: 13:Sun door 14:BSD whiteout 5:XENIX named file
 *  3/7:multiplexed char/block device)
 * and we use 0 for unknown and 15 for executables (see below) */
#define TYPEINDEX(mode) (((mode) >> 12) & 0x0f)
/*                       un  fi chr -   dir -  blk  -  file -  link - sock -   - exe */
#define APPCHAR(mode)   ("\0""|""\0""\0""/""\0""\0""\0""\0""\0""@""\0""=""\0""\0""\0" [TYPEINDEX(mode)])
/* 036 black foreground              050 black background
   037 red foreground                051 red background
   040 green foreground              052 green background
   041 brown foreground              053 brown background
   042 blue foreground               054 blue background
   043 magenta (purple) foreground   055 magenta background
   044 cyan (light blue) foreground  056 cyan background
   045 gray foreground               057 white background
*/
#define COLOR(mode) ( \
	/*un  fi  chr  -  dir  -  blk  -  file -  link -  sock -   -  exe */ \
	"\037\043\043\045\042\045\043\043\000\045\044\045\043\045\045\040" \
	[TYPEINDEX(mode)])
/* Select normal (0) [actually "reset all"] or bold (1)
 * (other attributes are 2:dim 4:underline 5:blink 7:reverse,
 *  let's use 7 for "impossible" types, just for fun)
 * Note: coreutils 6.9 uses inverted red for setuid binaries.
 */
#define ATTR(mode) ( \
	/*un fi chr - dir - blk - file- link- sock- -  exe */ \
	"\01\00\01\07\01\07\01\07\00\07\01\07\01\07\07\01" \
	[TYPEINDEX(mode)])

#if ENABLE_FEATURE_LS_COLOR
/* mode of zero is interpreted as "unknown" (stat failed) */
static char fgcolor(mode_t mode)
{
	if (S_ISREG(mode) && (mode & (S_IXUSR | S_IXGRP | S_IXOTH)))
		return COLOR(0xF000);	/* File is executable ... */
	return COLOR(mode);
}
static char bold(mode_t mode)
{
	if (S_ISREG(mode) && (mode & (S_IXUSR | S_IXGRP | S_IXOTH)))
		return ATTR(0xF000);	/* File is executable ... */
	return ATTR(mode);
}
#endif

#if ENABLE_FEATURE_LS_FILETYPES
static char append_char(mode_t mode)
{
	if (!(option_mask32 & (OPT_F|OPT_p)))
		return '\0';

	if (S_ISDIR(mode))
		return '/';
	if (!(option_mask32 & OPT_F))
		return '\0';
	if (S_ISREG(mode) && (mode & (S_IXUSR | S_IXGRP | S_IXOTH)))
		return '*';
	return APPCHAR(mode);
}
#endif

/* Return the number of used columns.
 * Note that only columnar output uses return value.
 * -l and -1 modes don't care.
 * coreutils 7.2 also supports:
 * ls -b (--escape) = octal escapes (although it doesn't look like working)
 * ls -N (--literal) = not escape at all
 */
static unsigned calc_name_len(const char *name)
{
	unsigned len;
	uni_stat_t uni_stat;

	if (!(option_mask32 & (OPT_q|OPT_Q)))
		return strlen(name);

	if (!(option_mask32 & OPT_Q)) {
		/* the most likely branch: "ls" to tty (it auto-enables -q behavior) */
		printable_string2(&uni_stat, name);
		return uni_stat.unicode_width;
	}

	len = 2 + strlen(name);
	while (*name) {
	        unsigned char ch = (unsigned char)*name;
		if (ch < ' ' || ch > 0x7e) {
			ch -= 7;
			if (ch <= 6) {
				/* quote chars 7..13 as \a,b,t,n,v,f,r */
				goto two;
			}
			/* other chars <32 or >126 as \ooo octal */
			len += 3;
			goto next;
		}
		if (*name == '"' || *name == '\\') {
 two:
			len++;
		}
 next:
		name++;
	}
	return len;
}
static unsigned print_name(const char *name)
{
	unsigned len;
	uni_stat_t uni_stat;

	if (!(option_mask32 & (OPT_q|OPT_Q))) {
		fputs_stdout(name);
		return strlen(name);
	}

	if (!(option_mask32 & OPT_Q)) {
		/* the most likely branch: "ls" to tty (it auto-enables -q behavior) */
		name = printable_string2(&uni_stat, name);
		fputs_stdout(name);
		return uni_stat.unicode_width;
	}

	len = 2 + strlen(name);
	putchar('"');
	while (*name) {
	        unsigned char ch = (unsigned char)*name;
		if (ch < ' ' || ch > 0x7e) {
			putchar('\\');
			ch -= 7;
			if (ch <= 6) {
				/* quote chars 7..13 as \a,b,t,n,v,f,r */
				ch = c_escape_conv_str07[1 + 3 * ch];
				goto two;
			}
			/* other chars <32 or >126 as \ooo octal */
			ch = (unsigned char)*name;
			putchar('0' + (ch>>6));
			putchar('0' + ((ch>>3) & 7));
			ch = '0' + (ch & 7);
			len += 3;
			goto put_ch;
		}
		if (ch == '"' || ch == '\\') {
			putchar('\\');
 two:
			len++;
		}
 put_ch:
		putchar(ch);
		name++;
	}
	putchar('"');
	return len;
}

/* Return the number of used columns.
 * Note that only columnar output uses return value,
 * -l and -1 modes don't care.
 */
static NOINLINE unsigned display_single(const struct dnode *dn)
{
	unsigned column = 0;
	char *lpath;
	int opt;
#if ENABLE_FEATURE_LS_FILETYPES || ENABLE_FEATURE_LS_COLOR
	struct stat statbuf;
#endif
#if ENABLE_FEATURE_LS_FILETYPES
	char append = append_char(dn->dn_mode);
#endif

	opt = option_mask32;

	/* Do readlink early, so that if it fails, error message
	 * does not appear *inside* the "ls -l" line */
	lpath = NULL;
	if (opt & OPT_l)
		if (S_ISLNK(dn->dn_mode))
			lpath = xmalloc_readlink_or_warn(dn->fullname);

	if (opt & OPT_i) /* show inode# */
#if !ENABLE_FEATURE_EXTRA_FILE_DATA
		column += printf("%7"LL_FMT"u ", (long long) dn->dn_ino);
#else
		column += printf("%19"LL_FMT"u ", (long long) dn->dn_ino);
#endif
	if (opt & OPT_s) { /* show allocated blocks */
		if (opt & OPT_h) {
			column += printf("%"HUMAN_READABLE_MAX_WIDTH_STR"s ",
				/* print size, show one fractional, use suffixes */
				make_human_readable_str((off_t)dn->dn_blocks << 9, 1, 0)
			);
		} else {
			column += printf("%6"OFF_FMT"u ", (off_t)(dn->dn_blocks >> 1));
		}
	}
	if (opt & OPT_l) {
		/* long listing: show mode */
		char modestr[12];
		column += printf("%-10s ", bb_mode_string(modestr, dn->dn_mode));
		/* long listing: show number of links */
		column += printf("%4lu ", (long) dn->dn_nlink);
		/* long listing: show user/group */
		if (opt & OPT_n) {
			if (opt & OPT_g)
				column += printf("%-8u ", (int) dn->dn_gid);
			else
				column += printf("%-8u %-8u ",
						(int) dn->dn_uid,
						(int) dn->dn_gid);
		}
#if ENABLE_FEATURE_LS_USERNAME
		else {
			if (opt & OPT_g) {
				column += printf("%-8s ",
					get_cached_groupname(dn->dn_gid));
			} else {
				column += printf("%-8s %-8s ",
					get_cached_username(dn->dn_uid),
					get_cached_groupname(dn->dn_gid));
			}
		}
#endif
#if ENABLE_SELINUX
	}
	if (opt & OPT_Z) {
		column += printf("%-32s ", dn->sid ? dn->sid : "?");
		freecon(dn->sid);
	}
	if (opt & OPT_l) {
#endif
		/* long listing: show size */
		if (S_ISBLK(dn->dn_mode) || S_ISCHR(dn->dn_mode)) {
			column += printf("%4u, %3u ",
					dn->dn_rdev_maj,
					dn->dn_rdev_min);
		} else {
			if (opt & OPT_h) {
				column += printf("%"HUMAN_READABLE_MAX_WIDTH_STR"s ",
					/* print size, show one fractional, use suffixes */
					make_human_readable_str(dn->dn_size, 1, 0)
				);
			} else {
				column += printf("%9"OFF_FMT"u ", dn->dn_size);
			}
		}
#if ENABLE_FEATURE_LS_TIMESTAMPS
		/* long listing: show {m,c,a}time */
		if (opt & OPT_full_time) { /* --full-time */
			/* coreutils 8.4 ls --full-time prints:
			 * 2009-07-13 17:49:27.000000000 +0200
			 * we don't show fractional seconds.
			 */
			char buf[sizeof("YYYY-mm-dd HH:MM:SS TIMEZONE")];
			strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S %z",
					localtime(&dn->dn_time));
			column += printf("%s ", buf);
		} else { /* ordinary time format */
			/* G.current_time_t is ~== time(NULL) */
			char *filetime = ctime(&dn->dn_time);
			/* filetime's format: "Wed Jun 30 21:49:08 1993\n" */
			time_t age = G.current_time_t - dn->dn_time;
			if (age < 3600L * 24 * 365 / 2 && age > -15 * 60) {
				/* less than 6 months old */
				/* "mmm dd hh:mm " */
				printf("%.12s ", filetime + 4);
			} else {
				/* "mmm dd  yyyy " */
				/* "mmm dd yyyyy " after year 9999 :) */
				strchr(filetime + 20, '\n')[0] = ' ';
				printf("%.7s%6s", filetime + 4, filetime + 20);
			}
			column += 13;
		}
#endif
	}

#if ENABLE_FEATURE_LS_COLOR
	if (G_show_color) {
		mode_t mode = dn->dn_mode_lstat;
		if (!mode)
			if (lstat(dn->fullname, &statbuf) == 0)
				mode = statbuf.st_mode;
		printf(ESC"[%u;%um", bold(mode), fgcolor(mode));
	}
#endif
	column += print_name(dn->name);
	if (G_show_color) {
		printf(ESC"[m");
	}

	if (lpath) {
		printf(" -> ");
#if ENABLE_FEATURE_LS_FILETYPES || ENABLE_FEATURE_LS_COLOR
		if ((opt & (OPT_F|OPT_p))
		 || G_show_color
		) {
			mode_t mode = dn->dn_mode_stat;
			if (!mode)
				if (stat(dn->fullname, &statbuf) == 0)
					mode = statbuf.st_mode;
# if ENABLE_FEATURE_LS_FILETYPES
			append = append_char(mode);
# endif
# if ENABLE_FEATURE_LS_COLOR
			if (G_show_color) {
				printf(ESC"[%u;%um", bold(mode), fgcolor(mode));
			}
# endif
		}
#endif
		column += print_name(lpath) + 4;
		free(lpath);
		if (G_show_color) {
			printf(ESC"[m");
		}
	}
#if ENABLE_FEATURE_LS_FILETYPES
	if (opt & (OPT_F|OPT_p)) {
		if (append) {
			putchar(append);
			column++;
		}
	}
#endif

	return column;
}

static void display_files(struct dnode **dn, unsigned nfiles)
{
	unsigned i, ncols, nrows, row, nc;
	unsigned column;
	unsigned nexttab;
	unsigned column_width = 0; /* used only by columnar output */

	if (option_mask32 & (OPT_l|OPT_1)) {
		ncols = 1;
	} else {
		/* find the longest file name, use that as the column width */
		for (i = 0; dn[i]; i++) {
			int len = calc_name_len(dn[i]->name);
			if (column_width < len)
				column_width = len;
		}
		column_width += 2
			+ ((option_mask32 & OPT_Z) ? 33 : 0) /* context width */
#if !ENABLE_FEATURE_EXTRA_FILE_DATA
			+ ((option_mask32 & OPT_i) ? 8 : 0) /* inode# width */
#else
			+ ((option_mask32 & OPT_i) ? 20 : 0) /* inode# width */
#endif
			+ ((option_mask32 & OPT_s) ? 5 : 0) /* "alloc block" width */
		;
		ncols = (unsigned)G_terminal_width / column_width;
	}

	if (ncols > 1) {
		nrows = nfiles / ncols;
		if (nrows * ncols < nfiles)
			nrows++;                /* round up fractionals */
	} else {
		nrows = nfiles;
		ncols = 1;
	}

	column = 0;
	nexttab = 0;
	for (row = 0; row < nrows; row++) {
		for (nc = 0; nc < ncols; nc++) {
			/* reach into the array based on the column and row */
			if (option_mask32 & OPT_x)
				i = (row * ncols) + nc;	/* display across row */
			else
				i = (nc * nrows) + row;	/* display by column */
			if (i < nfiles) {
				if (column > 0) {
					nexttab -= column;
					printf("%*s", nexttab, "");
					column += nexttab;
				}
				nexttab = column + column_width;
				column += display_single(dn[i]);
			} else {
				/* if -w999999999, ncols can be very large */
				//bb_error_msg(" col:%u ncol:%u i:%i", nc, ncols, i); sleep1();
				/* without "break", we loop millions of times here */
				break;
			}
		}
		putchar('\n');
		column = 0;
	}
}


/*** Dir scanning code ***/

static struct dnode *my_stat(const char *fullname, const char *name, int force_follow)
{
	struct stat statbuf;
	struct dnode *cur;

	cur = xzalloc(sizeof(*cur));
	cur->fullname = fullname;
	cur->name = name;

	if ((option_mask32 & OPT_L) || force_follow) {
#if ENABLE_SELINUX
		if (option_mask32 & OPT_Z) {
			getfilecon(fullname, &cur->sid);
		}
#endif
		if (stat(fullname, &statbuf)) {
			bb_simple_perror_msg(fullname);
			G.exit_code = EXIT_FAILURE;
			free(cur);
			return NULL;
		}
		cur->dn_mode_stat = statbuf.st_mode;
	} else {
#if ENABLE_SELINUX
		if (option_mask32 & OPT_Z) {
			lgetfilecon(fullname, &cur->sid);
		}
#endif
		if (lstat(fullname, &statbuf)) {
			bb_simple_perror_msg(fullname);
			G.exit_code = EXIT_FAILURE;
			free(cur);
			return NULL;
		}
		cur->dn_mode_lstat = statbuf.st_mode;
	}

	/* cur->dstat = statbuf: */
	cur->dn_mode   = statbuf.st_mode  ;
#if ENABLE_PLATFORM_MINGW32
	cur->dn_attr   = statbuf.st_attr  ;
#endif
	cur->dn_size   = statbuf.st_size  ;
#if ENABLE_FEATURE_LS_TIMESTAMPS || ENABLE_FEATURE_LS_SORTFILES
	cur->dn_time   = statbuf.st_mtime ;
	if (option_mask32 & OPT_u)
		cur->dn_time = statbuf.st_atime;
	if (option_mask32 & OPT_c)
		cur->dn_time = statbuf.st_ctime;
#endif
	cur->dn_ino    = statbuf.st_ino   ;
	cur->dn_blocks = statbuf.st_blocks;
	cur->dn_nlink  = statbuf.st_nlink ;
	cur->dn_uid    = statbuf.st_uid   ;
	cur->dn_gid    = statbuf.st_gid   ;
	cur->dn_rdev_maj = major(statbuf.st_rdev);
	cur->dn_rdev_min = minor(statbuf.st_rdev);

	return cur;
}

static unsigned count_dirs(struct dnode **dn, int which)
{
	unsigned dirs, all;

	if (!dn)
		return 0;

	dirs = all = 0;
	for (; *dn; dn++) {
		const char *name;

		all++;
		if (!S_ISDIR((*dn)->dn_mode))
			continue;

		name = (*dn)->name;
		if (which != SPLIT_SUBDIR /* if not requested to skip . / .. */
		 /* or if it's not . or .. */
		 || name[0] != '.'
		 || (name[1] && (name[1] != '.' || name[2]))
		) {
			dirs++;
		}
	}
	return which != SPLIT_FILE ? dirs : all - dirs;
}

/* get memory to hold an array of pointers */
static struct dnode **dnalloc(unsigned num)
{
	if (num < 1)
		return NULL;

	num++; /* so that we have terminating NULL */
	return xzalloc(num * sizeof(struct dnode *));
}

#if ENABLE_FEATURE_LS_RECURSIVE
static void dfree(struct dnode **dnp)
{
	unsigned i;

	if (dnp == NULL)
		return;

	for (i = 0; dnp[i]; i++) {
		struct dnode *cur = dnp[i];
		if (cur->fname_allocated)
			free((char*)cur->fullname);
		free(cur);
	}
	free(dnp);
}
#else
#define dfree(...) ((void)0)
#endif

/* Returns NULL-terminated malloced vector of pointers (or NULL) */
static struct dnode **splitdnarray(struct dnode **dn, int which)
{
	unsigned dncnt, d;
	struct dnode **dnp;

	if (dn == NULL)
		return NULL;

	/* count how many dirs or files there are */
	dncnt = count_dirs(dn, which);

	/* allocate a file array and a dir array */
	dnp = dnalloc(dncnt);

	/* copy the entrys into the file or dir array */
	for (d = 0; *dn; dn++) {
		if (S_ISDIR((*dn)->dn_mode)) {
			const char *name;

			if (which == SPLIT_FILE)
				continue;

			name = (*dn)->name;
			if ((which & SPLIT_DIR) /* any dir... */
			/* ... or not . or .. */
			 || name[0] != '.'
			 || (name[1] && (name[1] != '.' || name[2]))
			) {
				dnp[d++] = *dn;
			}
		} else
		if (which == SPLIT_FILE) {
			dnp[d++] = *dn;
		}
	}
	return dnp;
}

#if ENABLE_FEATURE_LS_SORTFILES
static int sortcmp(const void *a, const void *b)
{
	struct dnode *d1 = *(struct dnode **)a;
	struct dnode *d2 = *(struct dnode **)b;
	unsigned opt = option_mask32;
	off_t dif;

	dif = 0; /* assume sort by name */
	// TODO: use pre-initialized function pointer
	// instead of branch forest
	if (opt & OPT_dirs_first) {
		dif = S_ISDIR(d2->dn_mode) - S_ISDIR(d1->dn_mode);
		if (dif != 0)
			goto maybe_invert_and_ret;
	}

	if (opt & OPT_S) { /* sort by size */
		dif = (d2->dn_size - d1->dn_size);
	} else
	if (opt & OPT_t) { /* sort by time */
		dif = (d2->dn_time - d1->dn_time);
	} else
#if defined(HAVE_STRVERSCMP) && HAVE_STRVERSCMP == 1
	if (opt & OPT_v) { /* sort by version */
		dif = strverscmp(d1->name, d2->name);
	} else
#endif
	if (opt & OPT_X) { /* sort by extension */
		dif = strcmp(strchrnul(d1->name, '.'), strchrnul(d2->name, '.'));
	}
	if (dif == 0) {
		/* sort by name, use as tie breaker for other sorts */
		if (ENABLE_LOCALE_SUPPORT)
			dif = strcoll(d1->name, d2->name);
		else
			dif = strcmp(d1->name, d2->name);
	} else {
		/* Make dif fit into an int */
		if (sizeof(dif) > sizeof(int)) {
			enum { BITS_TO_SHIFT = 8 * (sizeof(dif) - sizeof(int)) };
			/* shift leaving only "int" worth of bits */
			/* (this requires dif != 0, and here it is nonzero) */
			dif = 1 | (int)((uoff_t)dif >> BITS_TO_SHIFT);
		}
	}
 maybe_invert_and_ret:
	return (opt & OPT_r) ? -(int)dif : (int)dif;
}

static void dnsort(struct dnode **dn, int size)
{
	qsort(dn, size, sizeof(*dn), sortcmp);
}

static void sort_and_display_files(struct dnode **dn, unsigned nfiles)
{
	dnsort(dn, nfiles);
	display_files(dn, nfiles);
}
#else
# define dnsort(dn, size) ((void)0)
# define sort_and_display_files(dn, nfiles) display_files(dn, nfiles)
#endif

#if ENABLE_PLATFORM_MINGW32
static int hide_file(DWORD attr)
{
	return
		((attr & FILE_ATTRIBUTE_HIDDEN) && !(option_mask32 & (OPT_a|OPT_A))) ||
		(((attr & HIDSYS) == HIDSYS) && MAX(G.a_count, G.A_count) > 1);
}
#endif

/* Returns NULL-terminated malloced vector of pointers (or NULL) */
static struct dnode **scan_one_dir(const char *path, unsigned *nfiles_p)
{
	struct dnode *dn, *cur, **dnp;
	struct dirent *entry;
	DIR *dir;
	unsigned i, nfiles;
#if ENABLE_PLATFORM_MINGW32
	struct stat statbuf;
#endif

	*nfiles_p = 0;
	dir = warn_opendir(path);
	if (dir == NULL) {
		G.exit_code = EXIT_FAILURE;
		return NULL;	/* could not open the dir */
	}
	dn = NULL;
	nfiles = 0;
	while ((entry = readdir(dir)) != NULL) {
		char *fullname;

		/* are we going to list the file- it may be . or .. or a hidden file */
		if (entry->d_name[0] == '.') {
			if (!(option_mask32 & (OPT_a|OPT_A)))
				continue; /* skip all dotfiles if no -a/-A */
			if (!(option_mask32 & OPT_a)
			 && (!entry->d_name[1] || (entry->d_name[1] == '.' && !entry->d_name[2]))
			) {
				continue; /* if only -A, skip . and .. but show other dotfiles */
			}
		}
#if ENABLE_PLATFORM_MINGW32
		if (has_dos_drive_prefix(path) && path[2] == '\0')
			fullname = xasprintf("%s%s", path, entry->d_name);
		else
#endif
		fullname = concat_path_file(path, entry->d_name);
#if ENABLE_PLATFORM_MINGW32
		/* When showing link targets we must first check the
		 * attributes of the link itself to see if it's hidden. */
		if ((option_mask32 & OPT_L) && !lstat(fullname, &statbuf)) {
			if (hide_file(statbuf.st_attr)) {
				free(fullname);
				continue;
			}
		}
#endif
		cur = my_stat(fullname, bb_basename(fullname), 0);
#if !ENABLE_PLATFORM_MINGW32
		if (!cur) {
#else
		if (!cur || hide_file(cur->dn_attr)) {
			/* skip invalid or hidden files */
#endif
			free(fullname);
			continue;
		}
		cur->fname_allocated = 1;
		cur->dn_next = dn;
		dn = cur;
		nfiles++;
	}
	closedir(dir);

	if (dn == NULL)
		return NULL;

	/* now that we know how many files there are
	 * allocate memory for an array to hold dnode pointers
	 */
	*nfiles_p = nfiles;
	dnp = dnalloc(nfiles);
	for (i = 0; /* i < nfiles - detected via !dn below */; i++) {
		dnp[i] = dn;	/* save pointer to node in array */
		dn = dn->dn_next;
		if (!dn)
			break;
	}

	return dnp;
}

#if ENABLE_DESKTOP
/* http://www.opengroup.org/onlinepubs/9699919799/utilities/ls.html
 * If any of the -l, -n, -s options is specified, each list
 * of files within the directory shall be preceded by a
 * status line indicating the number of file system blocks
 * occupied by files in the directory in 512-byte units if
 * the -k option is not specified, or 1024-byte units if the
 * -k option is specified, rounded up to the next integral
 * number of units.
 */
/* by Jorgen Overgaard (jorgen AT antistaten.se) */
static off_t calculate_blocks(struct dnode **dn)
{
	uoff_t blocks = 1;
	if (dn) {
		while (*dn) {
			/* st_blocks is in 512 byte blocks */
			blocks += (*dn)->dn_blocks;
			dn++;
		}
	}

	/* Even though standard says use 512 byte blocks, coreutils use 1k */
	/* Actually, we round up by calculating (blocks + 1) / 2,
	 * "+ 1" was done when we initialized blocks to 1 */
	return blocks >> 1;
}
#endif

static void scan_and_display_dirs_recur(struct dnode **dn, int first)
{
	unsigned nfiles;
	struct dnode **subdnp;

	for (; *dn; dn++) {
		if (G.show_dirname || (option_mask32 & OPT_R)) {
			if (!first)
				bb_putchar('\n');
			first = 0;
			printf("%s:\n", (*dn)->fullname);
		}
		subdnp = scan_one_dir((*dn)->fullname, &nfiles);
#if ENABLE_DESKTOP
		if (option_mask32 & (OPT_s|OPT_l)) {
			if (option_mask32 & OPT_h) {
				printf("total %-"HUMAN_READABLE_MAX_WIDTH_STR"s\n",
					/* print size, no fractions, use suffixes */
					make_human_readable_str(calculate_blocks(subdnp) * 1024,
								0, 0)
				);
			} else {
				printf("total %"OFF_FMT"u\n", calculate_blocks(subdnp));
			}
		}
#endif
		if (nfiles > 0) {
			/* list all files at this level */
			sort_and_display_files(subdnp, nfiles);

			if (ENABLE_FEATURE_LS_RECURSIVE
			 && (option_mask32 & OPT_R)
			) {
				struct dnode **dnd;
				unsigned dndirs;
				/* recursive - list the sub-dirs */
				dnd = splitdnarray(subdnp, SPLIT_SUBDIR);
				dndirs = count_dirs(subdnp, SPLIT_SUBDIR);
				if (dndirs > 0) {
					dnsort(dnd, dndirs);
					scan_and_display_dirs_recur(dnd, 0);
					/* free the array of dnode pointers to the dirs */
					free(dnd);
				}
			}
			/* free the dnodes and the fullname mem */
			dfree(subdnp);
		}
	}
}

#if ENABLE_PLATFORM_MINGW32
static char *fix_backslash(char *p)
{
	const char *flag = getenv("BB_FIX_BACKSLASH");
	int value = flag ? atoi(flag) : 0;

	if (value == 1)
		bs_to_slash(p);
	return p;
}
#endif


int ls_main(int argc UNUSED_PARAM, char **argv)
{	/*      ^^^^^^^^^^^^^^^^^ note: if FTPD, argc can be wrong, see ftpd.c */
	struct dnode **dnd;
	struct dnode **dnf;
	struct dnode **dnp;
	struct dnode *dn;
	struct dnode *cur;
	unsigned opt;
	unsigned nfiles;
	unsigned dnfiles;
	unsigned dndirs;
	unsigned i;
#if ENABLE_FEATURE_LS_COLOR
	/* colored LS support by JaWi, janwillem.janssen@lxtreme.nl */
	/* coreutils 6.10:
	 * # ls --color=BOGUS
	 * ls: invalid argument 'BOGUS' for '--color'
	 * Valid arguments are:
	 * 'always', 'yes', 'force'
	 * 'never', 'no', 'none'
	 * 'auto', 'tty', 'if-tty'
	 * (and substrings: "--color=alwa" work too)
	 */
	static const char color_str[] ALIGN1 =
		"always\0""yes\0""force\0"
		"auto\0""tty\0""if-tty\0";
	/* need to initialize since --color has _an optional_ argument */
	const char *color_opt = color_str; /* "always" */
#endif

	INIT_G();

	init_unicode();

	/* process options */
	opt = getopt32long(argv, "^"
		ls_options
			"\0"
			/* -n and -g imply -l */
			"nl:gl"
			/* --full-time implies -l */
			IF_FEATURE_LS_TIMESTAMPS(IF_LONG_OPTS(":\xff""l"))
			/* http://pubs.opengroup.org/onlinepubs/9699919799/utilities/ls.html:
			 * in some pairs of opts, only last one takes effect:
			 */
			IF_FEATURE_LS_TIMESTAMPS(IF_FEATURE_LS_SORTFILES(":t-S:S-t")) /* time/size */
			// ":m-l:l-m" - we don't have -m
			IF_FEATURE_LS_FOLLOWLINKS(":H-L:L-H")
			":C-xl:x-Cl:l-xC" /* bycols/bylines/long */
			":C-1:1-C" /* bycols/oneline */
			":x-1:1-x" /* bylines/oneline (not in SuS, but in GNU coreutils 8.4) */
			IF_FEATURE_LS_TIMESTAMPS(":c-u:u-c") /* mtime/atime */
			/* -w NUM: */
			IF_FEATURE_LS_WIDTH(":w+")
			IF_PLATFORM_MINGW32(":aa:AA")
		, ls_longopts
		IF_FEATURE_LS_WIDTH(, /*-T*/ NULL, /*-w*/ &G_terminal_width)
		IF_FEATURE_LS_COLOR(, &color_opt)
		IF_PLATFORM_MINGW32(, &G.a_count, &G.A_count)
	);
#if 0 /* option bits debug */
	bb_error_msg("opt:0x%08x l:%x H:%x color:%x dirs:%x", opt, OPT_l, OPT_H, OPT_color, OPT_dirs_first);
	if (opt & OPT_c         ) bb_error_msg("-c");
	if (opt & OPT_l         ) bb_error_msg("-l");
	if (opt & OPT_H         ) bb_error_msg("-H");
	if (opt & OPT_color     ) bb_error_msg("--color");
	if (opt & OPT_dirs_first) bb_error_msg("--group-directories-first");
	if (opt & OPT_full_time ) bb_error_msg("--full-time");
	exit(0);
#endif

	/* ftpd secret backdoor? */
	if (ENABLE_FTPD && applet_name[0] == 'f') {
		/* dirs first are much nicer */
		opt = option_mask32 |= OPT_dirs_first;
		/* don't show SEcontext */
		IF_SELINUX(opt = option_mask32 &= ~OPT_Z;)
		/* do not query stdout about size and tty-ness */
		IF_FEATURE_LS_WIDTH(G_terminal_width = INT_MAX;)
		G.tty_out = 1; /* not a tty */
		goto skip_if_ftpd;
	}

#if ENABLE_FEATURE_LS_WIDTH
	if ((int)G_terminal_width < 0) {
		/* obtain the terminal width */
		G_terminal_width = get_terminal_width(STDIN_FILENO);
		/* go one less... */
		G_terminal_width--;
	}
	if (G_terminal_width == 0) /* -w0 */
		G_terminal_width = INT_MAX; /* "infinite" */
#endif

#if ENABLE_SELINUX
	if (opt & OPT_Z) {
		if (!is_selinux_enabled())
			option_mask32 &= ~OPT_Z;
	}
#endif

#if ENABLE_FEATURE_LS_COLOR
	/* set G_show_color = 1/0 */
	if (ENABLE_FEATURE_LS_COLOR_IS_DEFAULT && !is_TERM_dumb()) {
		char *p = getenv("LS_COLORS");
# if ENABLE_PLATFORM_MINGW32
		/* No colour if unset or empty: https://no-color.org */
		char *no_c = getenv("NO_COLOR");
		if (!no_c || no_c[0] == '\0')
# endif
		/* LS_COLORS is unset, or (not empty && not "none") ? */
		if (!p || (p[0] && strcmp(p, "none") != 0)) {
			if (G_isatty()) {
				/* check isatty() last because it's expensive (syscall) */
				G_show_color = 1;
			}
		}
	}
	if (opt & OPT_color) {
		if (color_opt[0] == 'n')
			G_show_color = 0;
		else if (!G_show_color) {
		/* if() is not needed, but avoids extra isatty() if G_show_color is already set */
			/* Check --color=COLOR_OPT and maybe set show_color=1 */
			switch (index_in_substrings(color_str, color_opt)) {
			case 3: // auto
			case 4: // tty
			case 5: // if-tty
				if (!is_TERM_dumb() && G_isatty()) {
			case 0: // always
			case 1: // yes
			case 2: // force
					G_show_color = 1;
				}
			}
		}
	}
#endif
 skip_if_ftpd:

	/* sort out which command line options take precedence */
	if (ENABLE_FEATURE_LS_RECURSIVE && (opt & OPT_d))
		opt = option_mask32 &= ~OPT_R;	/* no recurse if listing only dir */
	if (!(opt & OPT_l)) { /* not -l? */
		if (ENABLE_FEATURE_LS_TIMESTAMPS && ENABLE_FEATURE_LS_SORTFILES) {
			/* when to sort by time? -t[cu] sorts by time even with -l */
			/* (this is achieved by opt_flags[] element for -t) */
			/* without -l, bare -c or -u enable sort too */
			/* (with -l, bare -c or -u just select which time to show) */
			if (opt & (OPT_c|OPT_u)) {
				opt = option_mask32 |= OPT_t;
			}
		}
	}

	/* choose a display format if one was not already specified by an option */
	if (!(opt & (OPT_l|OPT_1|OPT_x|OPT_C)))
		opt = option_mask32 |= (G_isatty() ? OPT_C : OPT_1);

	if (!(opt & OPT_q) && G_isatty())
		opt = option_mask32 |= OPT_q;

#if ENABLE_FEATURE_EXTRA_FILE_DATA
	/* Enable accurate link counts for directories */
	if (opt & OPT_l)
		count_subdirs(NULL);
#endif

	argv += optind;
	if (!argv[0])
		*--argv = (char*)".";

	if (argv[1])
		G.show_dirname = 1; /* 2 or more items? label directories */

	/* stuff the command line file names into a dnode array */
	dn = NULL;
	nfiles = 0;
	do {
#if ENABLE_PLATFORM_MINGW32
		*argv = fix_backslash(*argv);
#endif
		cur = my_stat(*argv, *argv,
			/* follow links on command line unless -l, -i, -s or -F: */
			!(option_mask32 & (OPT_l|OPT_i|OPT_s|OPT_F))
			/* ... or if -H: */
			|| (option_mask32 & OPT_H)
			/* ... or if -L, but my_stat always follows links if -L */
		);
		argv++;
		if (!cur)
			continue;
		/*cur->fname_allocated = 0; - already is */
		cur->dn_next = dn;
		dn = cur;
		nfiles++;
	} while (*argv);

	/* nfiles _may_ be 0 here - try "ls doesnt_exist" */
	if (nfiles == 0)
		return G.exit_code;

	/* now that we know how many files there are
	 * allocate memory for an array to hold dnode pointers
	 */
	dnp = dnalloc(nfiles);
	for (i = 0; /* i < nfiles - detected via !dn below */; i++) {
		dnp[i] = dn;	/* save pointer to node in array */
		dn = dn->dn_next;
		if (!dn)
			break;
	}

	if (option_mask32 & OPT_d) {
		sort_and_display_files(dnp, nfiles);
	} else {
		dnd = splitdnarray(dnp, SPLIT_DIR);
		dnf = splitdnarray(dnp, SPLIT_FILE);
		dndirs = count_dirs(dnp, SPLIT_DIR);
		dnfiles = nfiles - dndirs;
		if (dnfiles > 0) {
			sort_and_display_files(dnf, dnfiles);
			if (ENABLE_FEATURE_CLEAN_UP)
				free(dnf);
		}
		if (dndirs > 0) {
			dnsort(dnd, dndirs);
			scan_and_display_dirs_recur(dnd, dnfiles == 0);
			if (ENABLE_FEATURE_CLEAN_UP)
				free(dnd);
		}
	}

	if (ENABLE_FEATURE_CLEAN_UP)
		dfree(dnp);
	return G.exit_code;
}
